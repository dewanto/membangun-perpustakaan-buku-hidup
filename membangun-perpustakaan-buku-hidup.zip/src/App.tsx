import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Vision from './components/Vision';
import FoundingMothers from './components/FoundingMothers';
import ScreeningForm from './components/ScreeningForm';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-cream">
      <Navbar />
      <Hero />
      <PainPoints />
      <Vision />
      <FoundingMothers />
      <ScreeningForm />
      <Footer />
    </div>
  );
}
