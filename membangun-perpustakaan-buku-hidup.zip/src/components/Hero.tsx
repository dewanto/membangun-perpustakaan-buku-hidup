export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Living Book Library"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-warm-900/60 via-warm-900/50 to-warm-900/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-warm-900/40 to-transparent" />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-10 text-5xl sm:text-7xl opacity-20 animate-float hidden sm:block">🌿</div>
      <div className="absolute bottom-32 left-10 text-4xl sm:text-5xl opacity-20 animate-float delay-300 hidden sm:block">📖</div>
      <div className="absolute top-40 left-1/4 text-3xl opacity-15 animate-float delay-500 hidden lg:block">🦋</div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-24 sm:py-32">
        <div className="max-w-3xl">
          {/* Badge */}
          <div className="animate-fade-in-up inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-4 sm:px-5 py-2 mb-6 sm:mb-8 border border-white/20">
            <span className="animate-gentle-pulse text-lg">🌱</span>
            <span className="text-white/90 text-xs sm:text-sm font-medium tracking-wide">Memanggil 20–30 Founding Mothers</span>
          </div>

          {/* Title */}
          <h1 className="animate-fade-in-up delay-100 font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-4 sm:mb-6">
            Living Book
            <br />
            <span className="text-warm-200">Library</span>
            <span className="text-sage-300 text-3xl sm:text-4xl md:text-5xl lg:text-6xl ml-2 sm:ml-3">🇮🇩</span>
          </h1>

          {/* Subtitle */}
          <p className="animate-fade-in-up delay-200 text-lg sm:text-xl md:text-2xl text-warm-100/90 font-light leading-relaxed mb-3 sm:mb-4 max-w-2xl">
            Ruang di mana <span className="font-medium text-white">AI & kepekaan seorang Ibu</span> berkolaborasi mengurasi literatur klasik bernuansa lokal Indonesia.
          </p>

          <p className="animate-fade-in-up delay-300 text-base sm:text-lg text-warm-200/80 italic font-display mb-8 sm:mb-10">
            "Karena ini terlalu berat dipikul sendiri"
          </p>

          {/* CTA Buttons */}
          <div className="animate-fade-in-up delay-400 flex flex-col sm:flex-row gap-3 sm:gap-4">
            <a
              href="#daftar"
              className="inline-flex items-center justify-center gap-2 bg-sage-600 hover:bg-sage-700 text-white px-7 sm:px-8 py-3.5 sm:py-4 rounded-full text-base sm:text-lg font-semibold transition-all shadow-xl shadow-sage-900/30 hover:shadow-2xl hover:scale-105"
            >
              <span>Daftar Founding Mothers</span>
              <span>🤎</span>
            </a>
            <a
              href="#tantangan"
              className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white px-7 sm:px-8 py-3.5 sm:py-4 rounded-full text-base sm:text-lg font-medium transition-all border border-white/20 backdrop-blur-sm"
            >
              <span>Pelajari Lebih Lanjut</span>
              <span>↓</span>
            </a>
          </div>

          {/* Stats */}
          <div className="animate-fade-in-up delay-500 mt-12 sm:mt-16 flex flex-wrap gap-6 sm:gap-8 md:gap-12">
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-white">2,000+</div>
              <div className="text-xs sm:text-sm text-warm-200/70">Views di Threads</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-sage-300">25</div>
              <div className="text-xs sm:text-sm text-warm-200/70">Moms Antusias</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-warm-200">50</div>
              <div className="text-xs sm:text-sm text-warm-200/70">Target Buku Pertama</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-1.5">
          <div className="w-1.5 h-3 bg-white/60 rounded-full animate-gentle-pulse" />
        </div>
      </div>
    </section>
  );
}
