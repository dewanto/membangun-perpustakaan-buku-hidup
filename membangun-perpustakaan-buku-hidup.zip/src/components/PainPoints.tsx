export default function PainPoints() {
  const challenges = [
    {
      emoji: '🩹',
      title: 'Luka Inner-Child',
      description: 'Banyak Ibu enggan membaca karena pengalaman masa kecil yang menyakitkan terkait literasi.',
      color: 'from-rose-50 to-rose-100 border-rose-200',
      iconBg: 'bg-rose-100',
    },
    {
      emoji: '💸',
      title: 'Buku Mahal & Impor',
      description: 'Living books berkualitas didominasi buku impor dengan harga yang tidak terjangkau.',
      color: 'from-amber-50 to-amber-100 border-amber-200',
      iconBg: 'bg-amber-100',
    },
    {
      emoji: '🕸️',
      title: 'Akses Web CM Raib',
      description: 'Sumber bacaan Charlotte Mason lokal yang tersedia di web tiba-tiba menghilang tanpa kejelasan.',
      color: 'from-slate-50 to-slate-100 border-slate-200',
      iconBg: 'bg-slate-100',
    },
    {
      emoji: '📜',
      title: 'Bahasa Era Victoria',
      description: 'Ingin menerjemahkan sendiri tapi terbentur diksi dan bahasa abad ke-19 yang rumit.',
      color: 'from-violet-50 to-violet-100 border-violet-200',
      iconBg: 'bg-violet-100',
    },
    {
      emoji: '🏙️',
      title: 'Nature Study di Kota',
      description: 'Rekan di perkotaan kesulitan nature journaling di kepungan beton dan gedung tinggi.',
      color: 'from-sky-50 to-sky-100 border-sky-200',
      iconBg: 'bg-sky-100',
    },
    {
      emoji: '⏰',
      title: 'Waktu Terbatas',
      description: 'Repot bernarasi dan menerapkan CM di sela-sela PR sekolah dan aktivitas harian.',
      color: 'from-emerald-50 to-emerald-100 border-emerald-200',
      iconBg: 'bg-emerald-100',
    },
  ];

  return (
    <section id="tantangan" className="py-16 sm:py-20 md:py-24 bg-gradient-to-b from-cream to-parchment">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block text-sm font-semibold text-warm-500 tracking-widest uppercase mb-3 sm:mb-4">
            Tantangan Nyata
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-warm-900 mb-4 sm:mb-6">
            Beban Kognitif yang <br className="hidden sm:block" />
            <span className="text-sage-600">Kita Pikul Bersama</span>
          </h2>
          <p className="text-base sm:text-lg text-warm-600 max-w-2xl mx-auto leading-relaxed">
            Menjalankan homeschool Charlotte Mason di Indonesia bukan perkara mudah.
            Ini adalah tantangan nyata yang dihadapi banyak keluarga.
          </p>
        </div>

        {/* Challenge cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {challenges.map((item, index) => (
            <div
              key={index}
              className={`group relative bg-gradient-to-br ${item.color} border rounded-2xl sm:rounded-3xl p-6 sm:p-8 hover:shadow-xl transition-all duration-500 hover:-translate-y-1`}
            >
              <div className={`${item.iconBg} w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl mb-4 sm:mb-5 group-hover:scale-110 transition-transform`}>
                {item.emoji}
              </div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-warm-900 mb-2 sm:mb-3">
                {item.title}
              </h3>
              <p className="text-sm sm:text-base text-warm-700 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        {/* Transition quote */}
        <div className="mt-12 sm:mt-16 text-center">
          <div className="inline-flex items-center gap-2 sm:gap-3 bg-white/70 backdrop-blur-sm rounded-full px-6 sm:px-8 py-3 sm:py-4 shadow-md border border-warm-200">
            <span className="text-xl sm:text-2xl">✨</span>
            <p className="font-display text-base sm:text-lg md:text-xl text-warm-800 italic">
              "Perjalanan ini sungguh butuh kesabaran, namun selalu ada jalan."
            </p>
            <span className="text-xl sm:text-2xl">🌱</span>
          </div>
        </div>
      </div>
    </section>
  );
}
