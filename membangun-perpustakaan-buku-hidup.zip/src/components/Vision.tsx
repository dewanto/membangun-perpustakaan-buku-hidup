export default function Vision() {
  const dreams = [
    {
      emoji: '🤝',
      text: 'Lahirnya komunitas organik yang saling menopang para pemula',
    },
    {
      emoji: '🏛️',
      text: 'Platform Perpustakaan Living Books yang dikurasi & divalidasi penggiat CM Indonesia',
    },
    {
      emoji: '🇮🇩',
      text: 'Terjemahan karya era Victoria dengan rasa, diksi, dan nuansa sastra lokal Indonesia',
    },
    {
      emoji: '🤖',
      text: 'AI membantu teknis, Ibu fokus temani anak bertumbuh',
    },
  ];

  return (
    <section id="visi" className="py-16 sm:py-20 md:py-24 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-sage-800 to-sage-900" />
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 text-6xl sm:text-8xl">📖</div>
        <div className="absolute bottom-20 right-10 text-5xl sm:text-7xl">🌿</div>
        <div className="absolute top-1/3 right-1/4 text-4xl sm:text-6xl">🦋</div>
        <div className="absolute bottom-1/3 left-1/4 text-4xl sm:text-5xl">🌸</div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-10 sm:gap-12 lg:gap-16 items-center">
          {/* Left: Vision text */}
          <div>
            <span className="inline-block text-sm font-semibold text-sage-300 tracking-widest uppercase mb-3 sm:mb-4">
              Visi Kami
            </span>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4 sm:mb-6 leading-tight">
              Mimpi Itu Kini <br />
              <span className="text-warm-200">Mulai Dirajut</span> 🧶
            </h2>
            <p className="text-base sm:text-lg text-sage-100/80 leading-relaxed mb-6 sm:mb-8">
              Kami sedang membangun <strong className="text-white">Living Book Library</strong> — ruang
              di mana kecerdasan buatan dan kepekaan seorang Ibu berkolaborasi.
              Misi kita: mengurasi & menerjemahkan literatur klasik menjadi
              <em className="text-warm-200"> mahakarya bernuansa lokal Indonesia.</em>
            </p>

            <div className="space-y-4 sm:space-y-5">
              {dreams.map((dream, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 sm:gap-4 bg-white/5 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-5 border border-white/10 hover:bg-white/10 transition-colors"
                >
                  <span className="text-2xl sm:text-3xl flex-shrink-0 mt-0.5">{dream.emoji}</span>
                  <p className="text-sm sm:text-base text-sage-100 leading-relaxed">{dream.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Process visual */}
          <div className="relative">
            <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 sm:p-8 md:p-10 border border-white/15">
              <h3 className="font-display text-xl sm:text-2xl font-bold text-white mb-6 sm:mb-8 text-center">
                Bagaimana Cara Kerjanya?
              </h3>

              <div className="space-y-5 sm:space-y-6">
                {[
                  {
                    step: '01',
                    title: 'AI Sortir & Ringkas',
                    desc: 'AI membantu menyortir metadata, meringkas, dan menilai kesesuaian prinsip CM.',
                    emoji: '🤖',
                  },
                  {
                    step: '02',
                    title: 'Ibu Validasi & Kurasi',
                    desc: 'Validasi akhir tetap di tangan Ibu. Kita yang bedah isi dan "nyawa"-nya.',
                    emoji: '👩‍🏫',
                  },
                  {
                    step: '03',
                    title: 'Terjemahan Bernuansa Lokal',
                    desc: 'Karya era Victoria diterjemahkan dengan diksi dan rasa sastra Indonesia.',
                    emoji: '🇮🇩',
                  },
                  {
                    step: '04',
                    title: 'Read-Aloud Mingguan',
                    desc: 'Ritual membaca bersama untuk membangun kebiasaan dan komunitas.',
                    emoji: '📚',
                  },
                ].map((item, index) => (
                  <div key={index} className="flex gap-3 sm:gap-4 items-start">
                    <div className="flex-shrink-0 w-12 h-12 sm:w-14 sm:h-14 bg-sage-600/40 rounded-xl sm:rounded-2xl flex items-center justify-center">
                      <span className="text-xl sm:text-2xl">{item.emoji}</span>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-sage-400">{item.step}</span>
                        <h4 className="font-semibold text-white text-sm sm:text-base">{item.title}</h4>
                      </div>
                      <p className="text-xs sm:text-sm text-sage-200/70 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -top-4 -right-2 sm:-top-6 sm:-right-4 bg-warm-400 text-white px-3 sm:px-5 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-bold shadow-xl rotate-3">
              ☕ Fase Awal
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
