export default function FoundingMothers() {
  const privileges = [
    {
      emoji: '🏅',
      title: 'Badge Founding Mother',
      desc: 'Badge khusus sebagai perintis pertama yang dikenang selamanya.',
    },
    {
      emoji: '♾️',
      title: 'Akses Fitur Lifetime',
      desc: 'Semua fitur premium terbuka seumur hidup tanpa biaya tambahan.',
    },
    {
      emoji: '🗳️',
      title: 'Penentu Arah Platform',
      desc: 'Suara Moms menentukan arah pengembangan taman baca ini.',
    },
    {
      emoji: '📚',
      title: 'Akses 50 Buku Pertama',
      desc: 'Turut mengurasi dan mendapat akses eksklusif koleksi perdana.',
    },
    {
      emoji: '🎙️',
      title: 'Read-Aloud Mingguan',
      desc: 'Ikut ritual membaca bersama yang membangun kebiasaan literasi.',
    },
    {
      emoji: '🤝',
      title: 'Komunitas Eksklusif',
      desc: 'Bergabung dengan 20–30 Ibu terpilih yang saling menopang.',
    },
  ];

  return (
    <section id="founding-mothers" className="py-16 sm:py-20 md:py-24 bg-gradient-to-b from-parchment to-cream">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block text-sm font-semibold text-sage-600 tracking-widest uppercase mb-3 sm:mb-4">
            Privilege Eksklusif
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-warm-900 mb-4 sm:mb-6 leading-tight">
            Menjadi <span className="text-sage-600">Founding Mother</span> 🌱
          </h2>
          <p className="text-base sm:text-lg text-warm-600 max-w-2xl mx-auto leading-relaxed">
            Sebagai Founding Mothers, Moms adalah penentu arah taman baca ini.
            Yang merintis di awal akan mendapat privilege istimewa.
          </p>
        </div>

        {/* Privilege cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-12 sm:mb-16">
          {privileges.map((item, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl sm:rounded-3xl p-6 sm:p-8 shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-1 border border-warm-100"
            >
              <div className="w-14 h-14 sm:w-16 sm:h-16 bg-sage-50 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl mb-4 sm:mb-5 group-hover:scale-110 group-hover:bg-sage-100 transition-all">
                {item.emoji}
              </div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-warm-900 mb-2">
                {item.title}
              </h3>
              <p className="text-sm sm:text-base text-warm-600 leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Target section */}
        <div className="bg-gradient-to-r from-sage-600 to-sage-700 rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-12 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 text-[100px] sm:text-[150px] opacity-10 leading-none">📚</div>
          <div className="relative z-10 grid md:grid-cols-2 gap-6 sm:gap-8 items-center">
            <div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">
                Target Awal Kita 🎯
              </h3>
              <p className="text-sage-100 text-sm sm:text-base leading-relaxed mb-4 sm:mb-6">
                Kita tak mau membuka pintu perpustakaan yang kosong. Bersama Founding Mothers,
                target awal kita cuma satu: <strong className="text-white">mengurasi 50 Living Books pertama
                berbahasa Indonesia.</strong>
              </p>
              <p className="text-sage-100 text-sm sm:text-base leading-relaxed">
                Bisa terjemahan klasik, sejarah lokal, atau nature study. AI bantu sortir metadatanya,
                kita yang bedah isinya. Pelan-pelan saja, tak perlu buru-buru,
                <em> yang penting nyawanya dapet.</em>
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              {[
                { num: '50', label: 'Living Books', sub: 'Target Kurasi' },
                { num: '20-30', label: 'Founding Mothers', sub: 'Tim Inti' },
                { num: '1x', label: 'Per Minggu', sub: 'Read-Aloud' },
                { num: '∞', label: 'Lifetime', sub: 'Akses Fitur' },
              ].map((stat, index) => (
                <div
                  key={index}
                  className="bg-white/10 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-5 text-center border border-white/15"
                >
                  <div className="text-2xl sm:text-3xl font-bold text-warm-100">{stat.num}</div>
                  <div className="text-xs sm:text-sm font-medium text-white mt-1">{stat.label}</div>
                  <div className="text-xs text-sage-200/70">{stat.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
