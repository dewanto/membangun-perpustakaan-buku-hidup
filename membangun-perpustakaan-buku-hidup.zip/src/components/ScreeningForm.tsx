import { useState } from 'react';

interface FormData {
  namaLengkap: string;
  whatsapp: string;
  kota: string;
  email: string;
  statusHS: string;
  lamaKenalCM: string;
  sumberKenalCM: string;
  bukuCMDibaca: string;
  alasanGabung: string;
  waktuPerMinggu: string;
  readAloud: string;
  kesiapanKurasi: string;
  keahlianTambahan: string[];
  harapan: string;
  akunThreads: string;
  persetujuan: boolean;
}

const initialFormData: FormData = {
  namaLengkap: '',
  whatsapp: '',
  kota: '',
  email: '',
  statusHS: '',
  lamaKenalCM: '',
  sumberKenalCM: '',
  bukuCMDibaca: '',
  alasanGabung: '',
  waktuPerMinggu: '',
  readAloud: '',
  kesiapanKurasi: '',
  keahlianTambahan: [],
  harapan: '',
  akunThreads: '',
  persetujuan: false,
};

export default function ScreeningForm() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [submitted, setSubmitted] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 3;

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      if (name === 'persetujuan') {
        setFormData((prev) => ({ ...prev, [name]: checked }));
      } else {
        setFormData((prev) => ({
          ...prev,
          keahlianTambahan: checked
            ? [...prev.keahlianTambahan, value]
            : prev.keahlianTambahan.filter((v) => v !== value),
        }));
      }
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Save to localStorage as backup
    const existingEntries = JSON.parse(localStorage.getItem('lbl_founding_mothers') || '[]');
    existingEntries.push({ ...formData, timestamp: new Date().toISOString() });
    localStorage.setItem('lbl_founding_mothers', JSON.stringify(existingEntries));
    setSubmitted(true);
    window.scrollTo({ top: document.getElementById('daftar')?.offsetTop, behavior: 'smooth' });
  };

  const canProceed = (step: number) => {
    switch (step) {
      case 1:
        return formData.namaLengkap && formData.whatsapp && formData.kota && formData.statusHS;
      case 2:
        return formData.lamaKenalCM && formData.alasanGabung;
      case 3:
        return formData.waktuPerMinggu && formData.readAloud && formData.persetujuan;
      default:
        return false;
    }
  };

  const inputClass =
    'w-full bg-white border border-warm-200 rounded-xl px-4 py-3 text-warm-900 placeholder-warm-400 focus:outline-none focus:ring-2 focus:ring-sage-400 focus:border-sage-400 transition-all text-sm sm:text-base';
  const labelClass = 'block text-sm font-semibold text-warm-800 mb-1.5';
  const hintClass = 'text-xs text-warm-500 mt-1';

  if (submitted) {
    return (
      <section id="daftar" className="py-16 sm:py-20 md:py-24 bg-gradient-to-b from-cream to-sage-50">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 text-center">
          <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-xl border border-sage-100">
            <div className="text-6xl sm:text-7xl mb-6">🌱</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-sage-700 mb-4">
              Terima Kasih, Founding Mother! 🤎
            </h2>
            <p className="text-base sm:text-lg text-warm-600 mb-6 leading-relaxed">
              Data Moms sudah kami terima. Tim kami akan meninjau dan menghubungi
              via WhatsApp dalam <strong>1×24 jam</strong> untuk mengundang ke grup eksklusif Founding Mothers.
            </p>

            <div className="bg-sage-50 rounded-2xl p-5 sm:p-6 mb-8 text-left border border-sage-100">
              <h3 className="font-semibold text-sage-800 mb-3 flex items-center gap-2">
                <span>📋</span> Langkah Selanjutnya:
              </h3>
              <ol className="space-y-2 text-sm text-warm-700">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-sage-600">1.</span>
                  Tunggu pesan WhatsApp dari tim LBL
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-sage-600">2.</span>
                  Bergabung ke grup WA Founding Mothers
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-sage-600">3.</span>
                  Ikuti sesi perkenalan & orientasi virtual
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-sage-600">4.</span>
                  Mulai mengurasi buku pertama bersama! ☕
                </li>
              </ol>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://threads.net"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-warm-800 text-white px-6 py-3 rounded-full font-medium hover:bg-warm-900 transition-colors"
              >
                <span>Ikuti Kami di Threads</span>
                <span>🧵</span>
              </a>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setFormData(initialFormData);
                  setCurrentStep(1);
                }}
                className="inline-flex items-center justify-center gap-2 bg-warm-100 text-warm-700 px-6 py-3 rounded-full font-medium hover:bg-warm-200 transition-colors"
              >
                Daftarkan Teman
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="daftar" className="py-16 sm:py-20 md:py-24 bg-gradient-to-b from-cream to-sage-50 relative">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 right-20 text-8xl hidden sm:block">📖</div>
        <div className="absolute bottom-32 left-20 text-7xl hidden sm:block">🌿</div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Header */}
        <div className="text-center mb-10 sm:mb-12">
          <span className="inline-block text-sm font-semibold text-sage-600 tracking-widest uppercase mb-3 sm:mb-4">
            Form Pendaftaran
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-warm-900 mb-4 sm:mb-6">
            Daftar <span className="text-sage-600">Founding Mothers</span> 🌱
          </h2>
          <p className="text-base sm:text-lg text-warm-600 max-w-xl mx-auto leading-relaxed">
            Siap ngopi virtual bareng membahas buku anak pertama kita? ☕
            <br />Isi form di bawah untuk bergabung.
          </p>
        </div>

        {/* Progress bar */}
        <div className="mb-8 sm:mb-10">
          <div className="flex justify-between items-center mb-3">
            {[1, 2, 3].map((step) => (
              <button
                key={step}
                onClick={() => step < currentStep && setCurrentStep(step)}
                className={`flex items-center gap-2 text-xs sm:text-sm font-medium transition-colors ${
                  step === currentStep
                    ? 'text-sage-700'
                    : step < currentStep
                    ? 'text-sage-500 cursor-pointer hover:text-sage-700'
                    : 'text-warm-400'
                }`}
              >
                <span
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs sm:text-sm font-bold transition-all ${
                    step === currentStep
                      ? 'bg-sage-600 text-white shadow-lg shadow-sage-200'
                      : step < currentStep
                      ? 'bg-sage-200 text-sage-700'
                      : 'bg-warm-200 text-warm-500'
                  }`}
                >
                  {step < currentStep ? '✓' : step}
                </span>
                <span className="hidden sm:inline">
                  {step === 1 ? 'Data Diri' : step === 2 ? 'Pengalaman CM' : 'Komitmen'}
                </span>
              </button>
            ))}
          </div>
          <div className="h-2 bg-warm-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-sage-400 to-sage-600 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl sm:rounded-3xl shadow-xl p-5 sm:p-8 md:p-10 border border-warm-100">
          {/* Step 1: Data Diri */}
          {currentStep === 1 && (
            <div className="space-y-5 sm:space-y-6">
              <div className="flex items-center gap-3 mb-6 sm:mb-8">
                <span className="text-2xl sm:text-3xl">👩</span>
                <div>
                  <h3 className="font-display text-xl sm:text-2xl font-bold text-warm-900">Data Diri</h3>
                  <p className="text-xs sm:text-sm text-warm-500">Kenalan dulu, yuk!</p>
                </div>
              </div>

              <div>
                <label className={labelClass}>
                  Nama Lengkap <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  name="namaLengkap"
                  value={formData.namaLengkap}
                  onChange={handleChange}
                  placeholder="Nama panggilan boleh disertakan"
                  className={inputClass}
                  required
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4 sm:gap-5">
                <div>
                  <label className={labelClass}>
                    No. WhatsApp <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    name="whatsapp"
                    value={formData.whatsapp}
                    onChange={handleChange}
                    placeholder="08xxxxxxxxxx"
                    className={inputClass}
                    required
                  />
                  <p className={hintClass}>Akan digunakan untuk undangan grup</p>
                </div>
                <div>
                  <label className={labelClass}>
                    Kota Domisili <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="kota"
                    value={formData.kota}
                    onChange={handleChange}
                    placeholder="Contoh: Bandung"
                    className={inputClass}
                    required
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Email (opsional)</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="email@contoh.com"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  Status Homeschool <span className="text-rose-500">*</span>
                </label>
                <select
                  name="statusHS"
                  value={formData.statusHS}
                  onChange={handleChange}
                  className={inputClass}
                  required
                >
                  <option value="">-- Pilih --</option>
                  <option value="sudah_hs_cm">Sudah homeschool dengan metode CM</option>
                  <option value="sudah_hs_lain">Sudah homeschool, metode lain (ingin CM)</option>
                  <option value="berencana_hs">Berencana homeschool</option>
                  <option value="sekolah_formal_cm">Anak sekolah formal, terapkan CM di rumah</option>
                  <option value="belajar_cm">Masih belajar tentang CM</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>Akun Threads / Instagram</label>
                <input
                  type="text"
                  name="akunThreads"
                  value={formData.akunThreads}
                  onChange={handleChange}
                  placeholder="@username"
                  className={inputClass}
                />
                <p className={hintClass}>Agar kami bisa follow back & terhubung</p>
              </div>
            </div>
          )}

          {/* Step 2: Pengalaman CM */}
          {currentStep === 2 && (
            <div className="space-y-5 sm:space-y-6">
              <div className="flex items-center gap-3 mb-6 sm:mb-8">
                <span className="text-2xl sm:text-3xl">📚</span>
                <div>
                  <h3 className="font-display text-xl sm:text-2xl font-bold text-warm-900">Pengalaman Charlotte Mason</h3>
                  <p className="text-xs sm:text-sm text-warm-500">Tidak harus berpengalaman, yang penting mau belajar 🤎</p>
                </div>
              </div>

              <div>
                <label className={labelClass}>
                  Sudah berapa lama mengenal CM? <span className="text-rose-500">*</span>
                </label>
                <select
                  name="lamaKenalCM"
                  value={formData.lamaKenalCM}
                  onChange={handleChange}
                  className={inputClass}
                  required
                >
                  <option value="">-- Pilih --</option>
                  <option value="baru_dengar">Baru dengar / kurang dari 3 bulan</option>
                  <option value="3_12_bulan">3–12 bulan</option>
                  <option value="1_2_tahun">1–2 tahun</option>
                  <option value="2_5_tahun">2–5 tahun</option>
                  <option value="lebih_5_tahun">Lebih dari 5 tahun</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>Dari mana mengenal Charlotte Mason?</label>
                <input
                  type="text"
                  name="sumberKenalCM"
                  value={formData.sumberKenalCM}
                  onChange={handleChange}
                  placeholder="Contoh: Instagram, komunitas, buku, dll"
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  Buku/sumber CM apa saja yang sudah dibaca?
                </label>
                <textarea
                  name="bukuCMDibaca"
                  value={formData.bukuCMDibaca}
                  onChange={handleChange}
                  placeholder="Contoh: Home Education vol.1, blog Simply Charlotte Mason, dll. Kosongkan jika belum ada."
                  rows={3}
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>
                  Kenapa ingin bergabung sebagai Founding Mother? <span className="text-rose-500">*</span>
                </label>
                <textarea
                  name="alasanGabung"
                  value={formData.alasanGabung}
                  onChange={handleChange}
                  placeholder="Ceritakan motivasi dan harapan Moms bergabung..."
                  rows={4}
                  className={inputClass}
                  required
                />
                <p className={hintClass}>Jawaban jujur lebih berharga dari jawaban sempurna 💛</p>
              </div>

              <div>
                <label className={labelClass}>Keahlian tambahan yang bisa dikontribusikan</label>
                <div className="grid grid-cols-2 gap-2 sm:gap-3 mt-2">
                  {[
                    'Menerjemahkan (Inggris-Indonesia)',
                    'Menulis / menyunting teks',
                    'Desain grafis / ilustrasi',
                    'Review & analisis buku',
                    'Moderasi komunitas',
                    'Membaca nyaring (read-aloud)',
                    'Pengetahuan nature study',
                    'Teknologi / website',
                  ].map((skill) => (
                    <label
                      key={skill}
                      className="flex items-start gap-2 bg-warm-50 hover:bg-sage-50 rounded-xl p-2.5 sm:p-3 cursor-pointer transition-colors border border-warm-100 hover:border-sage-200"
                    >
                      <input
                        type="checkbox"
                        name="keahlianTambahan"
                        value={skill}
                        checked={formData.keahlianTambahan.includes(skill)}
                        onChange={handleChange}
                        className="mt-0.5 accent-sage-600 w-4 h-4 flex-shrink-0"
                      />
                      <span className="text-xs sm:text-sm text-warm-700">{skill}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Komitmen */}
          {currentStep === 3 && (
            <div className="space-y-5 sm:space-y-6">
              <div className="flex items-center gap-3 mb-6 sm:mb-8">
                <span className="text-2xl sm:text-3xl">🤝</span>
                <div>
                  <h3 className="font-display text-xl sm:text-2xl font-bold text-warm-900">Komitmen & Harapan</h3>
                  <p className="text-xs sm:text-sm text-warm-500">Kita saling menopang, bertumbuh bersama 🌱</p>
                </div>
              </div>

              <div>
                <label className={labelClass}>
                  Berapa jam per minggu yang bisa dialokasikan? <span className="text-rose-500">*</span>
                </label>
                <select
                  name="waktuPerMinggu"
                  value={formData.waktuPerMinggu}
                  onChange={handleChange}
                  className={inputClass}
                  required
                >
                  <option value="">-- Pilih --</option>
                  <option value="1_2_jam">1–2 jam/minggu</option>
                  <option value="3_5_jam">3–5 jam/minggu</option>
                  <option value="5_10_jam">5–10 jam/minggu</option>
                  <option value="lebih_10_jam">Lebih dari 10 jam/minggu</option>
                  <option value="fleksibel">Fleksibel, tergantung minggu itu</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  Bersedia ikut ritual Read-Aloud mingguan? <span className="text-rose-500">*</span>
                </label>
                <select
                  name="readAloud"
                  value={formData.readAloud}
                  onChange={handleChange}
                  className={inputClass}
                  required
                >
                  <option value="">-- Pilih --</option>
                  <option value="ya_rutin">Ya, siap rutin setiap minggu</option>
                  <option value="ya_sesekali">Ya, tapi mungkin tidak setiap minggu</option>
                  <option value="mungkin">Mau coba dulu, lihat jadwal</option>
                  <option value="belum_yakin">Belum yakin, tapi tertarik</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>
                  Kesiapan mengurasi buku
                </label>
                <select
                  name="kesiapanKurasi"
                  value={formData.kesiapanKurasi}
                  onChange={handleChange}
                  className={inputClass}
                >
                  <option value="">-- Pilih --</option>
                  <option value="sangat_siap">Sangat siap, ini yang saya cari!</option>
                  <option value="siap_belajar">Siap, tapi masih perlu belajar caranya</option>
                  <option value="ikut_dulu">Mau ikut dulu, lihat prosesnya</option>
                  <option value="lebih_ke_terjemahan">Lebih tertarik ke sisi terjemahan</option>
                </select>
              </div>

              <div>
                <label className={labelClass}>Harapan untuk Living Book Library</label>
                <textarea
                  name="harapan"
                  value={formData.harapan}
                  onChange={handleChange}
                  placeholder="Apa yang Moms harap bisa tercapai lewat komunitas ini?"
                  rows={3}
                  className={inputClass}
                />
              </div>

              {/* Agreement */}
              <div className="bg-sage-50 rounded-2xl p-4 sm:p-6 border border-sage-100">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    name="persetujuan"
                    checked={formData.persetujuan}
                    onChange={handleChange}
                    className="mt-1 accent-sage-600 w-5 h-5 flex-shrink-0"
                    required
                  />
                  <span className="text-sm text-warm-700 leading-relaxed">
                    Saya bersedia menjadi bagian dari Founding Mothers Living Book Library,
                    berkontribusi sesuai kemampuan, dan menjaga semangat kolaborasi yang
                    hangat & saling menopang. Saya memahami ini adalah fase awal yang
                    membutuhkan kesabaran bersama. 🌱
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* Navigation buttons */}
          <div className="flex justify-between items-center mt-8 sm:mt-10 pt-6 border-t border-warm-100">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(currentStep - 1)}
                className="flex items-center gap-2 text-warm-600 hover:text-warm-800 font-medium transition-colors text-sm sm:text-base"
              >
                <span>←</span>
                <span>Kembali</span>
              </button>
            ) : (
              <div />
            )}

            {currentStep < totalSteps ? (
              <button
                type="button"
                onClick={() => canProceed(currentStep) && setCurrentStep(currentStep + 1)}
                disabled={!canProceed(currentStep)}
                className={`flex items-center gap-2 px-6 sm:px-8 py-3 rounded-full font-semibold transition-all text-sm sm:text-base ${
                  canProceed(currentStep)
                    ? 'bg-sage-600 text-white hover:bg-sage-700 shadow-lg shadow-sage-200 hover:shadow-xl'
                    : 'bg-warm-200 text-warm-400 cursor-not-allowed'
                }`}
              >
                <span>Lanjut</span>
                <span>→</span>
              </button>
            ) : (
              <button
                type="submit"
                disabled={!canProceed(currentStep)}
                className={`flex items-center gap-2 px-6 sm:px-8 py-3 sm:py-3.5 rounded-full font-bold transition-all text-sm sm:text-base ${
                  canProceed(currentStep)
                    ? 'bg-sage-600 text-white hover:bg-sage-700 shadow-lg shadow-sage-200 hover:shadow-xl hover:scale-105'
                    : 'bg-warm-200 text-warm-400 cursor-not-allowed'
                }`}
              >
                <span>Kirim Pendaftaran</span>
                <span>🌱</span>
              </button>
            )}
          </div>
        </form>

        {/* Trust indicators */}
        <div className="mt-6 sm:mt-8 text-center">
          <p className="text-xs sm:text-sm text-warm-500 flex items-center justify-center gap-2 flex-wrap">
            <span>🔒</span>
            <span>Data Moms aman & hanya digunakan untuk keperluan komunitas Living Book Library</span>
          </p>
        </div>
      </div>
    </section>
  );
}
