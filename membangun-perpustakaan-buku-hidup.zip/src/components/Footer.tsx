export default function Footer() {
  return (
    <footer className="bg-warm-900 text-warm-200 py-12 sm:py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10 mb-10 sm:mb-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">📚</span>
              <div>
                <h3 className="font-display text-xl font-bold text-white">Living Book Library</h3>
                <p className="text-xs text-warm-400">Charlotte Mason Indonesia</p>
              </div>
            </div>
            <p className="text-sm text-warm-400 leading-relaxed max-w-sm">
              Ruang di mana AI & kepekaan seorang Ibu berkolaborasi mengurasi
              literatur klasik bernuansa lokal Indonesia. 🇮🇩
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Navigasi</h4>
            <ul className="space-y-2.5">
              {[
                { href: '#tantangan', label: 'Tantangan' },
                { href: '#visi', label: 'Visi & Misi' },
                { href: '#founding-mothers', label: 'Founding Mothers' },
                { href: '#daftar', label: 'Daftar Sekarang' },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-warm-400 hover:text-white transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Terhubung</h4>
            <div className="space-y-3">
              <a
                href="https://threads.net"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-warm-400 hover:text-white transition-colors"
              >
                <span>🧵</span>
                <span>Threads</span>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-warm-400 hover:text-white transition-colors"
              >
                <span>📸</span>
                <span>Instagram</span>
              </a>
              <div className="flex items-center gap-2 text-sm text-warm-400">
                <span>📧</span>
                <span>livingbooklibrary.id</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-warm-800 pt-6 sm:pt-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-xs text-warm-500 text-center sm:text-left">
              © 2025 Living Book Library. Dibangun dengan 🤎 untuk keluarga Charlotte Mason Indonesia.
            </p>
            <p className="text-xs text-warm-600 italic font-display text-center sm:text-right">
              "Education is an atmosphere, a discipline, a life." — Charlotte Mason
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
